"""Binary Trees

=== CSC148 Summer 2019 ===
Department of Mathematical and Computational Sciences,
University of Toronto Mississauga

=== Module Description ===
This module contains a binary tree node class and methods designed to solve
the Trick or Tree problem.
"""
from __future__ import annotations
from typing import Any, List, Optional, Tuple

class BinaryTree:
    """Binary Tree class.

    This class represents a binary tree with a key value, and optional
    left and right children who are also binary trees.
    """
    # === Private Attributes ===
    # The item stored as this tree's key value, or None if the tree is empty.
    _key: Optional[Any]
    # The left subtree, or None if the tree is empty.
    _left: Optional[BinaryTree]
    # The right subtree, or None if the tree is empty.
    _right: Optional[BinaryTree]

    # Note that the constructor for this is a little different from the one we
    # saw in lecture. This one allows us to set the not just the item, but also
    # the left and right subtrees during initializaion
    def __init__(self, value: Any, left: Optional[BinaryTree]=None,
                 right: Optional[BinaryTree] =None) -> None:
      """Initialize this binary tree.
      """
      
      self._key, self._left, self._right = value, left, right

    def __repr__(self) -> str:
      """Return a string representation of this tree."""
      
      return 'BinaryTree({}, {}, {})'.format(self._key, str(self._left), str(self._right))

# Complete the functions below according to the handouts
def tree_sum(t: BinaryTree): 
  '''Return the sum of the leaves in t.
  
  >>> t = BinaryTree(None, BinaryTree(8), BinaryTree(9))
  >>> tree_sum(t)
  17
  '''


def tree_height(t: BinaryTree) -> int:
  '''Return the height of t
  
  >>> tree_height(BinaryTree(None, BinaryTree(None, BinaryTree(4)), BinaryTree(9)))
  2
  '''


def tree_paths(t: BinaryTree) -> int:
  '''Return number of paths to get from root of t,
  to all houses, and back to t.
  
  >>> tree_paths(BinaryTree(None, BinaryTree(4), BinaryTree(5)))
  4
  '''


def solve(t: BinaryTree) -> (int, int):
  '''Return the solution to the tree as a tuple of (paths, candy)
  
  >>> solve(BinaryTree(None, BinaryTree(5), BinaryTree(6)))
  (3, 11)
    '''
  

def read_bt(s: str) -> BinaryTree:
  '''s is a line that represents a binary tree.
  Return the BinaryTree corresponding to that string.
  
  >>> read_bt('(3 4)')
  BinaryTree(None, BinaryTree(3, None, None), BinaryTree(4, None, None))
  '''


def process(f) -> None:
  '''
  Solve the problem for all lines in file f.
  '''



if __name__ == '__main__':
  import doctest
  doctest.testmod()
  process(open('candy.txt'))
  

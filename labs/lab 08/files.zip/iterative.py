"""Binary Trees

=== CSC148 Summer 2019 ===
Department of Mathematical and Computational Sciences,
University of Toronto Mississauga

=== Module Description ===
This module contains a binary tree node class and methods designed to solve
the Trick or Tree problem.
"""
from __future__ import annotations
from typing import Any, List, Optional, Tuple

class BinaryTree:
    """Binary Tree class.

    This class represents a binary tree with a key value, and optional
    left and right children who are also binary trees.
    """
    # === Private Attributes ===
    # The item stored as this tree's key value, or None if the tree is empty.
    _key: Optional[Any]
    # The left subtree, or None if the tree is empty.
    _left: Optional[BinaryTree]
    # The right subtree, or None if the tree is empty.
    _right: Optional[BinaryTree]

    # Note that the constructor for this is a little different from the one we
    # saw in lecture. This one allows us to set the not just the item, but also
    # the left and right subtrees during initializaion
    def __init__(self, value: Any, left: Optional[BinaryTree]=None,
                 right: Optional[BinaryTree] =None) -> None:
      """Initialize this binary tree.
      """
      
      self._key, self._left, self._right = value, left, right

    def __repr__(self) -> str:
      """Return a string representation of this tree."""
      
      return 'BinaryTree({}, {}, {})'.format(self._key, str(self._left), str(self._right))

class Stack:
    """A last-in-first-out (LIFO) stack of items.

    Stores data in a last-in, first-out order. When removing an item from the
    stack, the most recently-added item is the one that is removed.
    """
    # === Private Attributes ===
    # _items:
    #     The items stored in this stack. The end of the list represents
    #     the top of the stack.
    _items: List

    def __init__(self) -> None:
        """Initialize a new empty stack."""
        self._items = []

    def is_empty(self) -> bool:
        """Return whether this stack contains no items.

        >>> s = Stack()
        >>> s.is_empty()
        True
        >>> s.push('hello')
        >>> s.is_empty()
        False
        """
        return self._items == []

    def push(self, item: Any) -> None:
        """Add a new element to the top of this stack."""
        self._items.append(item)

    def pop(self) -> Any:
        """Remove and return the element at the top of this stack.

        Raise an EmptyStackError if this stack is empty.

        >>> s = Stack()
        >>> s.push('hello')
        >>> s.push('goodbye')
        >>> s.pop()
        'goodbye'
        """
        if self.is_empty():
            raise EmptyStackError
        else:
            return self._items.pop()


class EmptyStackError(Exception):
    """Exception raised when an error occurs."""
    pass


def read_bt(s): # nasty iterative version
  '''s is a line that represents a binary tree.
  Return the BTNode corresponding to that string.
  
  >>> read_bt('4')
  BinaryTree(4, None, None)
  >>> read_bt('(3 4)')
  BinaryTree(None, BinaryTree(3, None, None), BinaryTree(4, None, None))
  >>> read_bt('((1 2) (3 4))')
  BinaryTree(None, BinaryTree(None, BinaryTree(1, None, None), BinaryTree(2, None, None)), BinaryTree(None, BinaryTree(3, None, None), BinaryTree(4, None, None)))
  '''
  return read_bt_helper(s)[0]

def read_bt_helper(s):
  st = Stack()
  current = (s, None, None, 0) # string, left, right, stage
  while True:
    s, left, right, stage = current
    if stage == 0:
      s = s.strip()
      if s[0] == '(':
        st.push((s, left, right, 1))
        current = s[1:], left, right, 0
      else: # a digit
        assert s[0].isdigit(), 'digit expected'
        i = 0
        while i < len(s) and s[i].isdigit():
          i = i + 1
        temp1, temp2 = BinaryTree(int(s[:i])), s[i:]
        if not st.is_empty():
          current = st.pop()
        else:
          return temp1, temp2
    elif stage == 1:
      left, s = temp1, temp2
      s = s.strip()
      st.push((s, left, right, 2))
      current = s, left, right, 0
    elif stage == 2:
      right, s = temp1, temp2
      s = s.strip()
      assert s[0] == ')', 'expected )'
      temp1, temp2 = BinaryTree(None, left, right), s[1:]
      if not st.is_empty():
        current = st.pop()
      else:
        return temp1, temp2
      
  

if __name__ == '__main__':
  import doctest
  doctest.testmod()

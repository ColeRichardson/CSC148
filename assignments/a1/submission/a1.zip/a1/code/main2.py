"""
This module initializes and runs the main game.
"""

from game2 import Game

if __name__ == "__main__":

    game = Game()
    game.on_execute()
